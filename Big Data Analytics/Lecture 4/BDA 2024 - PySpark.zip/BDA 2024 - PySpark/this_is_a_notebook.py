#%%

# load pyspark environment



# %%

findspark.init()
# %%

from pyspark.sql import SparkSession
# %%
spark = SparkSession.builder.appName("SparkSQL").getOrCreate()
# %%
df = spark.read.csv("data/titanic.csv", header=True, inferSchema=True)
# %%

df.show()
# %%
