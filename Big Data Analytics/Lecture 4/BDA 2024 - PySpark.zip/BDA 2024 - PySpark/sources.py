flights_url = "https://storage.googleapis.com/dask-tutorial-data/nycflights.tar.gz"
lazy_url = "http://www.google.com"
bag_url = "s3://dask-data/nyc-taxi/2015/yellow_tripdata_2015-01.csv"
